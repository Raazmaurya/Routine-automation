import os

os.system("logActiveWin.sh")